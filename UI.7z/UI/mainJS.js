/* Project Name: mockUp Page
AuthorAuthor: Rahul Shekhawat
Created: Octover 4, 2017
Description: JS file for mockUp */